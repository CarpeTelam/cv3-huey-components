$(function() {
  console.log("index_component.js");
});