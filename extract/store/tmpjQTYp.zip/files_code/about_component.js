/*
  With the component setup, about_component.js is required otherwise browser will get a 404
*/
